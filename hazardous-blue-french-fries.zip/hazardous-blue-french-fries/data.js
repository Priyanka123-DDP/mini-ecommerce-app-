export const categories = [
  {
    id: "1",
    title: "Fruits",
    data: [
      { id: "f1", name: "Apple" },
      { id: "f2", name: "Banana" },
    ],
  },
  {
    id: "2",
    title: "Vegetables",
    data: [
      { id: "v1", name: "Carrot" },
      { id: "v2", name: "Potato" },
    ],
  },
];
